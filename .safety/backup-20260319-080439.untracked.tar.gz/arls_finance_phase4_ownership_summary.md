# ARLS Finance Schedule Workflow Ownership Summary - Phase 4

## 최종 판정

`Acceptance blocked`

ARLS가 가시적 owner라는 구조 자체는 확인됐습니다. 다만 raw `1차 스케쥴 다운로드` 파일이 바로 publish 흐름으로 이어지지 않는 치명 결함 때문에 최종 acceptance는 아직 통과가 아닙니다.

## Ownership 확인 결과

| 항목 | 판정 | 근거 |
| --- | --- | --- |
| 1차 다운로드 ownership confirmed? | Partially | ARLS가 live-regenerated review workbook을 직접 생성하는 것은 확인됨. 다만 raw 1차 파일이 preview/publish에서 막혀 end-to-end ownership acceptance는 `P4-002`로 차단됨. |
| publish replace confirmed? | Yes, conditional | site+month 기준 v2 게시가 v1을 archive/history로 밀어내고 current/latest가 되는 것은 확인됨. 단, upload가 preview validation을 통과한 경우 기준이며 QA에서는 metadata-only workaround로 continuation 검증을 진행함. |
| 2차 다운로드 latest artifact confirmed? | Yes | 단일 site는 exact byte match, 멀티 site는 latest published workbook 기반의 multi-sheet bundle로 확인됨. |
| update-needed logic confirmed? | Yes | HQ last-seen/download ack 이후 더 새 publish가 생기면 `업데이트 필요`, 최신 2차 다운로드 후 `게시 완료`로 복귀함. |
| multi-site download confirmed? | Yes | 선택된 여러 site가 하나의 workbook으로 묶이고, visible sheet name이 site name과 정확히 일치함. |
| publish history confirmed? | Yes | latest 3 entries와 current/latest badge가 올바르게 반환됨. |
| workbook byte/content preservation confirmed? | Yes | formulas, conditional formatting, page setup, widths/heights, hidden rows/cols, merged cells, manual edits가 유지됨. |
| role visibility confirmed? | Partial | Supervisor/HQ/Developer 관련 동작은 확인. Vice Supervisor Flow A는 `P4-001`로 불일치. Flow B HQ 전용 제한은 확인됨. |

## 남은 unresolved defects

### P4-002 Critical

raw `1차 스케쥴 다운로드` 파일을 그대로 수정해서 업로드하면 preview 단계에서 차단됩니다.

- 결과:
  - `can_apply=false`
  - `blocked_reasons` 2건
- 영향:
  - ARLS visible owner flow의 핵심 체인 차단

### P4-001 Medium

Vice Supervisor가 Flow A를 사용할 수 있어야 한다는 Phase 4 기준과 달리 403으로 막힙니다.

## 결론

아래는 실질적으로 확인됐습니다.

- ARLS가 1차 다운로드를 live source에서 생성
- ARLS가 publish replace를 소유
- ARLS가 2차 다운로드 latest artifact packaging을 소유
- ARLS가 HQ site status / update-needed 계산을 소유

하지만 최종 운영 흐름을 `사용자 그대로` 기준으로 승인하려면 최소 아래 두 결함이 먼저 정리되어야 합니다.

1. `P4-002` raw 1차 파일 preview/publish 차단
2. `P4-001` Vice Supervisor Flow A role mismatch
