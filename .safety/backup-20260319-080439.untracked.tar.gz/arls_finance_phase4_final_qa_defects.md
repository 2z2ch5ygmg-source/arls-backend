# ARLS Finance Schedule Workflow Phase 4 Defects

## P4-002 Critical

### 제목

Raw `1차 스케쥴 다운로드` 파일이 그대로는 `업로드 미리보기`를 통과하지 못함

### 심각도

Critical

### 영향

의도된 핵심 운영 흐름인 아래 체인이 raw ARLS output 기준으로 완성되지 않습니다.

`1차 다운로드 -> 수정 -> 업로드 미리보기 -> 게시`

즉 ARLS가 직접 만든 review workbook을 운영자가 일반적인 방식으로 수정해 올리면, publish 단계로 넘어갈 수 없습니다.

### 재현 절차

1. Supervisor로 로그인
2. `GET /api/v1/schedules/finance-submission/review-excel`
3. 다운로드된 workbook의 visible sheet에서 일반 셀만 수정
4. 수정본을 `POST /api/v1/schedules/finance-submission/final-upload/preview`로 업로드

### 기대 결과

- preview가 `can_apply=true`
- blocked reason 없음
- raw 1차 파일이 publish flow의 정상 입력으로 인정되어야 함

### 실제 결과

- HTTP `200`
- `can_apply=false`
- `blocked_reasons`:
  - `현재 업로드에서 사용할 수 없는 파일입니다.`
  - `현재 게시 업로드에서 사용할 수 없는 파일입니다.`
- preview metadata:
  - `export_source_version = schedule_export.phase2.roundtrip:finance-review`

### 재현 증거

실제 재현 응답:

```json
{
  "status_code": 200,
  "blocked_reasons": [
    "현재 업로드에서 사용할 수 없는 파일입니다.",
    "현재 게시 업로드에서 사용할 수 없는 파일입니다."
  ],
  "metadata": {
    "tenant_code": "P4AFA01F",
    "site_code": "R701",
    "month": "2026-03",
    "export_source_version": "schedule_export.phase2.roundtrip:finance-review"
  },
  "can_apply": false
}
```

### 기술 원인

review export가 쓰는 source version과 upload validator allowlist가 서로 다릅니다.

- review export metadata write:
  - `app/routers/v1/schedules.py:15364`
- 허용 source version allowlist:
  - `app/routers/v1/schedules.py:280`
- validator check:
  - `app/routers/v1/schedules.py:1644`
  - `app/routers/v1/schedules.py:1678`

현재 코드상:

- review export writes:
  - `schedule_export.phase2.roundtrip:finance-review`
- validator allows only:
  - `schedule_export.phase2.roundtrip`

### QA 우회

Phase 4 다운스트림 검증은 이 결함 때문에 중단되지 않도록, hidden `_ARLS_EXPORT_META` 시트의 `export_source_version`만 허용 값으로 맞추는 metadata-only workaround를 사용했습니다.

우회 내용:

- workbook body/sheet content는 수정하지 않음
- hidden metadata only:
  - `schedule_export.phase2.roundtrip:finance-review`
  - -> `schedule_export.phase2.roundtrip`

이 우회는 QA continuation 용도이며, 제품 acceptance 해결책이 아닙니다.

### 권장 수정 방향

- review export와 upload validator가 같은 source version contract를 사용하게 맞출 것
- preferred:
  - review export metadata를 validator 허용 값과 동일하게 맞춤
- 또는
  - validator가 `:finance-review` suffix를 허용하도록 명시 확장

중요한 점:

- 프런트에서 억지 우회하지 말 것
- raw 1차 파일이 backend contract 차원에서 바로 게시 가능해야 함

## P4-001 Medium

### 제목

Vice Supervisor가 Flow A를 사용할 수 없어 Phase 4 role policy와 불일치

### 심각도

Medium

### 영향

Phase 4 검증 기준에서는 `Supervisor / Vice Supervisor`가 Flow A를 사용할 수 있어야 합니다. 현재는 Vice Supervisor가 review download부터 403으로 막혀 있습니다.

### 재현 절차

1. Vice Supervisor로 로그인
2. `GET /api/v1/schedules/finance-submission/review-excel`

### 기대 결과

- Vice Supervisor가 Flow A review download에 접근 가능

### 실제 결과

- HTTP `403`
- message: `접근 권한이 없습니다.`

### 재현 증거

- QA matrix scenario: `F3`
- automated result:
  - expected: `Vice Supervisor can access Flow A per Phase 4 verification rule`
  - actual: `status=403 message=접근 권한이 없습니다.`

### 기술 원인

Finance submission role gate가 Vice Supervisor를 허용하지 않습니다.

- `app/routers/v1/schedules.py:1036` ~ `1045`

현재 허용 role:

- `developer`
- `hq_admin`
- `supervisor`

Vice Supervisor는 포함되지 않습니다.

### 권장 수정 방향

- Phase 4 role policy를 최종 기준으로 유지할지 먼저 확정
- 최종 기준이 `Supervisor / Vice Supervisor can use Flow A`라면 backend role gate에 `vice_supervisor`를 포함해야 함

## 최종 defect 판단

출시/acceptance 관점 우선순위:

1. `P4-002` 먼저 해결
   - 핵심 operator flow 자체를 막음
2. `P4-001` 다음 정리
   - role policy mismatch

`P4-002`가 해결되기 전에는 Finance workflow end-to-end acceptance를 통과로 볼 수 없습니다.
