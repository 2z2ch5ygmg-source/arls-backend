# ARLS Finance Schedule Workflow Final Verification - Phase 4

## 검증 개요

- 검증 일시: 2026-03-18 KST
- 검증 대상: ARLS Finance schedule workflow
- 검증 범위: ARLS verification only
- 제외 범위: Sentrix 변경, 모바일 변경, UI 재설계, 백엔드 로직 수정
- 최종 판정: `조건부 검증 완료, 최종 acceptance blocked`

핵심 이유는 두 가지입니다.

1. `P4-002`  
   ARLS가 직접 생성한 `1차 스케쥴 다운로드` 원본을 그대로 수정해서 `업로드 미리보기`에 올리면 차단됩니다. 즉 의도된 Flow A가 raw file 기준으로는 끝까지 이어지지 않습니다.
2. `P4-001`  
   Phase 4 검증 기준상 Vice Supervisor는 Flow A 사용 가능해야 하는데, 현재 백엔드 권한 게이트는 403으로 막고 있습니다.

## 검증 환경

- 작업 경로: `/Users/mark/Desktop/rg-arls-dev`
- 로컬 ARLS 서버: `http://127.0.0.1:18081`
- API base: `http://127.0.0.1:18081/api/v1`
- 검증 DB: `postgresql://postgres:postgres@localhost:5432/arls_finance_phase4_verify`
- 템플릿 경로: `/Users/mark/Desktop/rg-arls-dev/app/templates/monthly_schedule_template.xlsx`
- 자동 검증 결과 파일: `/tmp/arls_finance_phase4_results.json`
- 자동 검증 스크립트: `/tmp/arls_finance_phase4_verify.py`

검증용 tenant/site/account:

- tenant: `P4AFA01F`
- month: `2026-03`
- site A: `R701 / P4_AFA01F_A`
- site B: `R702 / P4_AFA01F_B`
- site C: `R703 / P4_AFA01F_C`
- supervisor: `supervisor_a_afa01f`
- vice supervisor: `vice_a_afa01f`
- hq admin: `hq_admin_afa01f`
- master developer: `master_dev_afa01f`

## 검증 방법

### 1. 자동 API 검증

`/tmp/arls_finance_phase4_verify.py`로 아래를 순차 검증했습니다.

- Flow A 접근 권한
- 1차 다운로드 live regeneration
- 업로드 미리보기
- 게시
- 게시 replace
- 게시 이력
- 2차 단일/멀티 다운로드
- update-needed
- ack 후 상태 해제
- byte/content preservation
- 빈 상태와 invalid upload 오류

자동 검증 결과:

- 총 25건
- PASS 24건
- FAIL 1건

자동 검증 FAIL 1건은 `P4-001` Vice Supervisor Flow A 권한 불일치입니다.

### 2. 추가 수동 재현

자동 검증만으로는 놓치는 핵심 결함이 있어 별도 재현했습니다.

- raw `1차 스케쥴 다운로드` 파일을 정상 다운로드
- visible sheet의 일반 셀만 수정
- 그대로 `final-upload/preview` 호출

재현 결과:

- HTTP `200`
- `can_apply=false`
- `blocked_reasons`:
  - `현재 업로드에서 사용할 수 없는 파일입니다.`
  - `현재 게시 업로드에서 사용할 수 없는 파일입니다.`
- preview metadata의 `export_source_version`:
  - `schedule_export.phase2.roundtrip:finance-review`

이 결함이 `P4-002`입니다.

## 핵심 계약 검증 결과

### 1차 다운로드 live regeneration

확인됨.

- 첫 다운로드에서는 site A day body가 `12`, support slot1이 `BK 초기지원A`, day need가 `1`
- DB live state를 변경한 뒤 재다운로드에서는 body `8`, support slot1 `F 변경지원A`, day need `2`
- SHA와 review revision 모두 변경됨

즉 `1차 다운로드`는 저장된 옛 파일이 아니라 현재 ARLS + Sentrix materialized truth를 다시 조합해 생성합니다.

### 게시 replace

확인됨.

- 동일 site+month에 v1 게시 후 v2 게시
- v2가 `active_final_batch_id`
- publish history에는 최신 1건만 `is_current=true`
- v1은 이력으로 남고 current에서는 제외

### 2차 다운로드 latest artifact

확인됨.

- 단일 site 2차 다운로드의 SHA가 업로드된 게시본 SHA와 정확히 일치
- 멀티 site 2차 다운로드는 1 workbook / 2 visible sheets
- sheet name은 `P4_AFA01F_A`, `P4_AFA01F_B`로 site name과 정확히 일치
- sheet marker 값도 최신 게시본과 일치

### update-needed

확인됨.

- HQ가 site A v2를 본 뒤 supervisor가 v3 게시
- HQ workspace row가 `업데이트 필요`로 변경
- HQ가 최신 v3를 다시 다운로드하면 상태가 `게시 완료`로 복귀

### publish history latest 3

확인됨.

- 최신 3건만 반환
- 각 row에 `uploaded_at`, `actor`, `site_code`, `site_name`, `month`, `is_current`
- 최신 게시본 1건만 current badge 유지

### workbook byte/content preservation

확인됨.

다운로드된 2차 파일에서 아래 속성이 유지됐습니다.

- manual marker
- formula
- conditional formatting
- page setup orientation
- column width
- row height
- hidden row
- hidden column
- merged cells

단일 site 다운로드는 uploaded publish bytes와 SHA 기준으로 exact match였습니다.

## 중요한 해석

다운스트림 계약 검증 자체는 대부분 통과했습니다. 다만 그 과정에서 site A/site B publish 업로드는 검증 스크립트 내부에서 hidden metadata의 `export_source_version`을 허용 값으로만 맞추는 최소 우회가 들어갔습니다.

우회 내용:

- 파일 본문 내용은 수정하지 않음
- hidden `_ARLS_EXPORT_META` 시트의 `export_source_version`만
  - `schedule_export.phase2.roundtrip:finance-review`
  - -> `schedule_export.phase2.roundtrip`

이 우회는 QA continuation 용도였습니다. 제품 acceptance 기준으로는 우회 없이 raw 1차 파일이 바로 preview/publish 가능해야 합니다.

## 코드 inspection으로 보강한 항목

브라우저 E2E 대신 코드 inspection으로 보강 확인한 항목:

- Flow B selection controls
- valid site 미선택 시 2차 다운로드 버튼 비활성화
- technical metadata 기본 숨김 / DEV gated details

관련 위치:

- `frontend/js/app.js:13575`
- `frontend/js/app.js:13628`
- `frontend/js/app.js:13718`
- `frontend/js/app.js:13843`
- `frontend/js/app.js:13844`
- `frontend/js/app.js:13486`
- `frontend/js/app.js:13665`
- `frontend/index.html:2778`

## 발견 결함 요약

### P4-002 Critical

raw 1차 다운로드 파일의 `export_source_version`이 import validator 허용 집합과 맞지 않아 preview/publish가 막힙니다.

근거 코드:

- review export metadata write: `app/routers/v1/schedules.py:15364`
- allowlist: `app/routers/v1/schedules.py:280`
- validator: `app/routers/v1/schedules.py:1644` ~ `app/routers/v1/schedules.py:1679`

### P4-001 Medium

Vice Supervisor가 Flow A를 사용할 수 있어야 한다는 Phase 4 기준과 달리, 현재 권한 게이트는 supervisor/hq_admin/developer만 허용합니다.

근거 코드:

- `app/routers/v1/schedules.py:1036` ~ `app/routers/v1/schedules.py:1045`

## 결론

아래 항목은 확인됐습니다.

- 1차 다운로드 live regeneration
- publish replace by site+month
- 2차 다운로드 latest artifact retrieval
- update-needed logic
- multi-site workbook packaging
- publish history latest 3
- workbook byte/content preservation
- Flow B HQ role gating

하지만 최종 acceptance는 아직 통과로 볼 수 없습니다.

- raw 1차 파일이 바로 publish flow로 이어지지 않는 `P4-002`
- Vice Supervisor Flow A 권한 불일치 `P4-001`

따라서 Phase 4 최종 판정은 `acceptance blocked`입니다.
