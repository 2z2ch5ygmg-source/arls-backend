import json
import tempfile
import unittest
from unittest.mock import patch

import app


class SupportRosterBridgeRepairTests(unittest.TestCase):
    def setUp(self):
        self._tempdir = tempfile.TemporaryDirectory()
        self._original_data_dir = str(app.DATA_DIR)
        app.set_runtime_data_paths(self._tempdir.name)
        app.init_db()
        app.SUPPORT_ROSTER_BRIDGE_REPAIR_DONE = False

    def tearDown(self):
        app.SUPPORT_ROSTER_BRIDGE_REPAIR_DONE = False
        app.set_runtime_data_paths(self._original_data_dir)
        self._tempdir.cleanup()

    def _insert_ticket(self, *, template_type, status="pending", payload=None, updated_at="2026-03-18T00:55:00Z"):
        conn = app.db_connect()
        try:
            cursor = conn.execute(
                """
                INSERT INTO tickets (
                    display_no, template_type, title, description, location, site_id, tenant_id,
                    status, reporter_user_id, created_at, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    153,
                    template_type,
                    "bridge repair test",
                    "desc",
                    "R692",
                    "R692",
                    "srs_korea",
                    status,
                    1,
                    updated_at,
                    updated_at,
                ),
            )
            ticket_id = int(cursor.lastrowid or 0)
            conn.execute(
                """
                INSERT INTO tickets_template_fields (ticket_id, template_type, payload_json, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?)
                """,
                (
                    ticket_id,
                    template_type,
                    json.dumps(payload or {}, ensure_ascii=False),
                    updated_at,
                    updated_at,
                ),
            )
            conn.commit()
            return ticket_id
        finally:
            conn.close()

    def test_repair_enqueues_upsert_for_pending_internal_night_worker(self):
        ticket_id = self._insert_ticket(
            template_type="야간 지원 요청",
            status="pending",
            payload={
                "support_request_status": "pending",
                "request_date": "2026-03-10",
                "confirmed_workers": [
                    {
                        "affiliation": "자체",
                        "worker_name": "최미강",
                        "employee_name": "최미강",
                        "employee_id": "EMP-100",
                        "self_staff": True,
                        "raw_display": "자체 최미강",
                    }
                ],
            },
        )
        outbox_calls = []

        def _enqueue(**kwargs):
            outbox_calls.append(dict(kwargs))
            return True

        with patch.object(app, "enqueue_hr_approval_outbox_event", side_effect=_enqueue):
            summary = app.reconcile_support_roster_bridge_snapshots_once(limit=50, force=True)

        self.assertEqual(summary["upserts_enqueued"], 1)
        self.assertEqual(summary["retracts_enqueued"], 0)
        self.assertEqual(outbox_calls[0]["ticket_id"], ticket_id)
        self.assertEqual(outbox_calls[0]["event_type_override"], "OVERNIGHT_APPROVED")
        self.assertEqual(outbox_calls[0]["bridge_targets_override"][0]["employee_name"], "최미강")

    def test_repair_enqueues_retract_when_bridge_history_exists_but_current_targets_empty(self):
        ticket_id = self._insert_ticket(
            template_type="야간 지원 요청",
            status="pending",
            payload={
                "support_request_status": "pending",
                "request_date": "2026-03-10",
                "confirmed_workers": [],
            },
        )
        conn = app.db_connect()
        try:
            conn.execute(
                """
                INSERT INTO integration_outbox (
                    event_id, event_type, ticket_id, tenant_id, site_id, payload_json,
                    status, attempt_count, next_retry_at, last_error, created_at, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, 'SENT', 1, NULL, NULL, ?, ?)
                """,
                (
                    "SOC-153-OVERNIGHT_APPROVED-old",
                    "OVERNIGHT_APPROVED",
                    ticket_id,
                    "srs_korea",
                    "R692",
                    "{}",
                    "2026-03-18T00:00:00Z",
                    "2026-03-18T00:00:00Z",
                ),
            )
            conn.commit()
        finally:
            conn.close()

        outbox_calls = []

        def _enqueue(**kwargs):
            outbox_calls.append(dict(kwargs))
            return True

        with patch.object(app, "enqueue_hr_approval_outbox_event", side_effect=_enqueue):
            summary = app.reconcile_support_roster_bridge_snapshots_once(limit=50, force=True)

        self.assertEqual(summary["upserts_enqueued"], 0)
        self.assertEqual(summary["retracts_enqueued"], 1)
        self.assertEqual(outbox_calls[0]["ticket_id"], ticket_id)
        self.assertEqual(outbox_calls[0]["event_type_override"], "OVERNIGHT_RETRACTED")
        self.assertEqual(outbox_calls[0]["bridge_targets_override"], [])


if __name__ == "__main__":
    unittest.main()
