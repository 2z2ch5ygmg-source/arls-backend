import sqlite3
import unittest

import app


class AppleWeeklyTruthTenantCodeTests(unittest.TestCase):
    def setUp(self):
        self.conn = sqlite3.connect(":memory:")
        self.conn.row_factory = sqlite3.Row

    def tearDown(self):
        self.conn.close()

    def test_resolve_truth_tenant_code_uses_registry_tenant_code_for_uuid_tenant_id(self):
        self.conn.execute(
            """
            CREATE TABLE tenants (
                id TEXT PRIMARY KEY,
                tenant_code TEXT
            )
            """
        )
        self.conn.execute(
            "INSERT INTO tenants (id, tenant_code) VALUES (?, ?)",
            ("7d3997c3-346a-407e-a416-687fe0827992", "srs_korea"),
        )

        resolved = app.resolve_apple_weekly_truth_tenant_code(
            self.conn,
            tenant_id="7d3997c3-346a-407e-a416-687fe0827992",
            explicit_tenant_code="APPLE",
        )

        self.assertEqual(resolved, "srs_korea")

    def test_resolve_truth_tenant_code_keeps_explicit_non_legacy_override(self):
        resolved = app.resolve_apple_weekly_truth_tenant_code(
            self.conn,
            tenant_id="7d3997c3-346a-407e-a416-687fe0827992",
            explicit_tenant_code="srs_korea",
        )

        self.assertEqual(resolved, "srs_korea")


if __name__ == "__main__":
    unittest.main()
