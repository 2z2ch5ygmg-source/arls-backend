import sqlite3
import unittest
from unittest.mock import patch

import app


class _DummyWeeklyValidationHandler:
    _build_weekly_report_structure_validation_result = app.SecurityOpsHandler._build_weekly_report_structure_validation_result
    _serialize_google_sheet_mapping_row = app.SecurityOpsHandler._serialize_google_sheet_mapping_row
    _serialize_weekly_template_config_row = app.SecurityOpsHandler._serialize_weekly_template_config_row

    def __init__(self, *, mapping_row, template_row, engine_context):
        self._mapping_row = mapping_row
        self._template_row = template_row
        self._engine_context = engine_context

    def _find_google_sheet_mapping_row(self, conn, tenant_id, site_code, report_year="", allow_fallback=False):
        return self._mapping_row

    def _find_weekly_template_config_row(self, conn, tenant_id, template_group=app.GOOGLE_SHEET_TEMPLATE_GROUP_DEFAULT):
        return self._template_row

    def _build_weekly_ops_engine_context(self, conn, tenant_id, site_code, report_year):
        return self._engine_context


def _build_mapping_row():
    return {
        "id": 1,
        "site_code": "R692",
        "report_year": "2026",
        "site_name": "Apple_가로수길",
        "spreadsheet_id": "1AbCdEfGhIjKlMnOpQrStUvWxYz0123456789ABCD",
        "tab_name_rule": "month_auto",
        "last_tested_at": "",
        "last_test_status": "ok",
        "last_test_message": "",
        "created_at": "",
        "updated_at": "",
    }


def _build_template_row():
    return {
        "id": 1,
        "template_group": "APPLE",
        "template_spreadsheet_id": "1ZyXwVuTsRqPoNmLkJiHgFeDcBa9876543210WXYZ",
        "template_spreadsheet_url": "",
        "template_tab_name": "MASTER",
        "active": 1,
        "last_tested_at": "",
        "last_test_status": "ok",
        "last_test_message": "",
        "created_at": "",
        "updated_at": "",
    }


def _build_engine_context(ok=True):
    if not ok:
        return {
            "ok": False,
            "status_code": 400,
            "error": "스토어 기본정보(B1/O5/P5/Q5)가 설정되지 않았습니다.",
        }
    return {
        "ok": True,
        "status_code": 200,
        "error": "",
        "daytime_rules": {
            "supervisor": {"count_override": 1},
            "guards": {"weekday_count_override": 2},
        },
    }


class AppleWeeklyPhase2ValidationTests(unittest.TestCase):
    def setUp(self):
        self.conn = sqlite3.connect(":memory:")
        self.conn.row_factory = sqlite3.Row

    def tearDown(self):
        self.conn.close()

    @patch.object(app, "fetch_google_spreadsheet_metadata")
    def test_structure_validation_returns_warning_creatable_when_month_tabs_are_missing(self, mock_metadata):
        def _fake_metadata(spreadsheet_id):
            if spreadsheet_id == "1AbCdEfGhIjKlMnOpQrStUvWxYz0123456789ABCD":
                return {
                    "status": "ok",
                    "title": "R692 2026",
                    "sheets": ["01월", "02월"],
                }
            if spreadsheet_id == "1ZyXwVuTsRqPoNmLkJiHgFeDcBa9876543210WXYZ":
                return {
                    "status": "ok",
                    "title": "APPLE MASTER",
                    "sheets": ["MASTER"],
                }
            return {"status": "not_found", "message": "missing"}

        mock_metadata.side_effect = _fake_metadata
        handler = _DummyWeeklyValidationHandler(
            mapping_row=_build_mapping_row(),
            template_row=_build_template_row(),
            engine_context=_build_engine_context(ok=True),
        )

        result = handler._build_weekly_report_structure_validation_result(
            self.conn,
            tenant_id="srs_korea",
            site_code="R692",
            report_year="2026",
            reference_date="2026-03-16",
        )

        self.assertEqual(result["status"], "warning_creatable")
        self.assertTrue(result["gate"]["pre_generation_ready"])
        self.assertTrue(result["gate"]["can_create"])
        self.assertIn("03월", result["missing_tabs"])
        passed_labels = {row["label"] for row in result["passed_checks"]}
        self.assertIn("연도 링크 연결", passed_labels)
        self.assertIn("마스터 템플릿 준비", passed_labels)
        self.assertIn("기본정보(B1/O5/P5/Q5)", passed_labels)
        self.assertIn("월 생성 규칙/기본 규칙", passed_labels)

    @patch.object(app, "fetch_google_spreadsheet_metadata")
    def test_structure_validation_hard_fails_when_baseline_or_generation_rules_are_missing(self, mock_metadata):
        mock_metadata.side_effect = lambda spreadsheet_id: {
            "status": "ok",
            "title": "ok",
            "sheets": ["MASTER", "01월"],
        }
        handler = _DummyWeeklyValidationHandler(
            mapping_row=_build_mapping_row(),
            template_row=_build_template_row(),
            engine_context=_build_engine_context(ok=False),
        )

        result = handler._build_weekly_report_structure_validation_result(
            self.conn,
            tenant_id="srs_korea",
            site_code="R692",
            report_year="2026",
            reference_date="2026-03-16",
        )

        self.assertEqual(result["status"], "hard_fail")
        self.assertFalse(result["gate"]["pre_generation_ready"])
        missing_labels = {row["label"] for row in result["missing_checks"]}
        self.assertIn("기본정보(B1/O5/P5/Q5)", missing_labels)
        self.assertIn("월 생성 규칙/기본 규칙", missing_labels)


if __name__ == "__main__":
    unittest.main()
