import tempfile
import unittest
from unittest.mock import patch

import app


class SentrixIntegrationOutboxImmediateDeliveryTests(unittest.TestCase):
    def setUp(self):
        self._tempdir = tempfile.TemporaryDirectory()
        self._original_data_dir = str(app.DATA_DIR)
        app.set_runtime_data_paths(self._tempdir.name)
        app.init_db()

    def tearDown(self):
        app.set_runtime_data_paths(self._original_data_dir)
        self._tempdir.cleanup()

    def _insert_outbox_row(self, *, event_id, created_at):
        conn = app.db_connect()
        try:
            conn.execute(
                """
                INSERT INTO integration_outbox (
                    event_id, event_type, ticket_id, tenant_id, site_id, payload_json,
                    status, attempt_count, next_retry_at, last_error, created_at, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, 'PENDING', 0, NULL, NULL, ?, ?)
                """,
                (
                    event_id,
                    "SUPPORT_ASSIGNMENT_APPROVED",
                    101,
                    "srs_korea",
                    "R692",
                    "{}",
                    created_at,
                    created_at,
                ),
            )
            conn.commit()
        finally:
            conn.close()

    def _fetch_status(self, event_id):
        conn = app.db_connect()
        try:
            row = conn.execute(
                "SELECT status FROM integration_outbox WHERE event_id = ?",
                (event_id,),
            ).fetchone()
            return str(row["status"] if row else "")
        finally:
            conn.close()

    @patch("app._send_hr_webhook", return_value=(True, "http_200"))
    def test_targeted_batch_delivery_sends_requested_event_first(self, mock_send_hr_webhook):
        self._insert_outbox_row(
            event_id="SOC-older-event",
            created_at="2026-03-18T08:00:00Z",
        )
        self._insert_outbox_row(
            event_id="SOC-new-event",
            created_at="2026-03-18T08:00:05Z",
        )

        processed = app.process_integration_outbox_batch(limit=1, event_id="SOC-new-event")

        self.assertEqual(processed, 1)
        self.assertEqual(self._fetch_status("SOC-older-event"), "PENDING")
        self.assertEqual(self._fetch_status("SOC-new-event"), "SENT")
        self.assertEqual(mock_send_hr_webhook.call_count, 1)
        self.assertEqual(mock_send_hr_webhook.call_args.args[0], "SOC-new-event")


if __name__ == "__main__":
    unittest.main()
