import sqlite3
import unittest
from unittest.mock import patch

import app


class _DummyWeeklyPhase3ContextHandler:
    _build_weekly_phase2_context = app.SecurityOpsHandler._build_weekly_phase2_context
    _serialize_google_sheet_mapping_row = app.SecurityOpsHandler._serialize_google_sheet_mapping_row
    _serialize_weekly_template_config_row = app.SecurityOpsHandler._serialize_weekly_template_config_row
    _build_weekly_sync_target_ranges = app.SecurityOpsHandler._build_weekly_sync_target_ranges
    _parse_weekly_int_value = app.SecurityOpsHandler._parse_weekly_int_value
    _sort_weekly_sync_updates = app.SecurityOpsHandler._sort_weekly_sync_updates

    def __init__(self, *, mapping_row, template_row, engine_context):
        self._mapping_row = mapping_row
        self._template_row = template_row
        self._engine_context = engine_context

    def _find_google_sheet_mapping_row(self, conn, tenant_id, site_code, report_year="", allow_fallback=False):
        return self._mapping_row

    def _find_weekly_template_config_row(self, conn, tenant_id, template_group=app.GOOGLE_SHEET_TEMPLATE_GROUP_DEFAULT):
        return self._template_row

    def _build_weekly_ops_engine_context(self, conn, tenant_id, site_code, report_year):
        return self._engine_context

    def _load_weekly_overnight_ticket_map(self, conn, tenant_id, site_code, target_dates):
        return {}


def _build_mapping_row():
    return {
        "id": 1,
        "site_code": "R692",
        "report_year": "2026",
        "site_name": "Apple_가로수길",
        "spreadsheet_id": "1AbCdEfGhIjKlMnOpQrStUvWxYz0123456789ABCD",
        "tab_name_rule": "month_auto",
        "last_tested_at": "",
        "last_test_status": "ok",
        "last_test_message": "",
        "created_at": "",
        "updated_at": "",
    }


def _build_template_row(blank_tab=True):
    return {
        "id": 1,
        "template_group": "APPLE",
        "template_spreadsheet_id": "1ZyXwVuTsRqPoNmLkJiHgFeDcBa9876543210WXYZ",
        "template_spreadsheet_url": "",
        "template_tab_name": "" if blank_tab else "MASTER",
        "active": 1,
        "last_tested_at": "",
        "last_test_status": "ok",
        "last_test_message": "",
        "created_at": "",
        "updated_at": "",
    }


def _build_engine_context():
    return {
        "ok": True,
        "status_code": 200,
        "error": "",
        "baseline": {
            "weekday_l2": 5,
            "weekday_l1": 1,
            "weekend_holiday_l1": 6,
            "store_display_name": "R692 / Apple_가로수길",
        },
        "overtime_rules": {
            "threshold_minutes": 10,
            "reasons": ["행사 대응"],
        },
        "daytime_rules": {
            "supervisor": {
                "count_override": 1,
                "work_range": "08:00-18:00",
                "hours": 10,
                "weekdays": ["mon", "tue", "wed", "thu", "fri"],
                "include_holiday": False,
            },
            "guards": {
                "weekday_count_override": 2,
                "work_range": "10:00-22:00",
                "hours": 12,
                "weekdays": ["mon", "tue", "wed", "thu", "fri"],
                "include_holiday": False,
            },
        },
        "overrides": {},
    }


class AppleWeeklyPhase3TemplateReadinessTests(unittest.TestCase):
    def setUp(self):
        self.conn = sqlite3.connect(":memory:")
        self.conn.row_factory = sqlite3.Row

    def tearDown(self):
        self.conn.close()

    @patch.object(app, "test_google_template_connection")
    def test_phase2_context_accepts_saved_template_when_first_sheet_fallback_resolves(self, mock_template_test):
        mock_template_test.return_value = {
            "status": "ok",
            "message": "템플릿 연결됨(읽기 가능)",
            "template_tab_name": "MASTER",
            "spreadsheet_title": "APPLE MASTER",
            "sheets": ["MASTER", "가이드"],
        }
        handler = _DummyWeeklyPhase3ContextHandler(
            mapping_row=_build_mapping_row(),
            template_row=_build_template_row(blank_tab=True),
            engine_context=_build_engine_context(),
        )

        result = handler._build_weekly_phase2_context(
            self.conn,
            tenant_id="srs_korea",
            site_code="R692",
            report_year="2026",
            target_dates=["2026-03-16"],
            sections=["daytime_supervisor"],
            reference_date="2026-03-16",
        )

        self.assertTrue(result["ok"])
        readiness = result["readiness"]
        self.assertTrue(readiness["template_ready"])
        self.assertFalse(any(item.get("kind") == "template_missing" for item in readiness["blockers"]))
        self.assertEqual(result["preview"]["template"]["template_tab_name"], "MASTER")


if __name__ == "__main__":
    unittest.main()
