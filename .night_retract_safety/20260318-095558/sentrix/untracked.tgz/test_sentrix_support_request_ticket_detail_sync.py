import json
import tempfile
import unittest
from datetime import date, timedelta
from types import MethodType
from urllib.parse import urlparse
from unittest.mock import patch

import app


class _BrokerStub:
    def broadcast(self, *args, **kwargs):
        return True


class SentrixSupportRequestTicketDetailSyncTests(unittest.TestCase):
    def setUp(self):
        self._tempdir = tempfile.TemporaryDirectory()
        self._original_data_dir = str(app.DATA_DIR)
        app.set_runtime_data_paths(self._tempdir.name)
        app.init_db()
        self.timestamp = app.now_iso()
        self._seed_runtime_data()

    def tearDown(self):
        app.set_runtime_data_paths(self._original_data_dir)
        self._tempdir.cleanup()

    def _seed_runtime_data(self):
        conn = app.db_connect()
        try:
            conn.execute(
                """
                INSERT INTO sites (tenant_id, site_id, site_name, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?)
                ON CONFLICT(tenant_id, site_id) DO UPDATE SET
                    site_name = excluded.site_name,
                    updated_at = excluded.updated_at
                """,
                ("srs_korea", "R692", "Apple 가로수길", self.timestamp, self.timestamp),
            )
            for username, full_name, role in [
                ("detail_hq_admin", "상세 본사", "hq_admin"),
                ("detail_reporter", "상세 등록자", "supervisor"),
            ]:
                conn.execute(
                    """
                    INSERT INTO users (
                        username, full_name, role, location, site_id, site_name, tenant_id,
                        status, password_hash, created_at, updated_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ON CONFLICT(username) DO UPDATE SET
                        full_name = excluded.full_name,
                        role = excluded.role,
                        location = excluded.location,
                        site_id = excluded.site_id,
                        site_name = excluded.site_name,
                        tenant_id = excluded.tenant_id,
                        status = excluded.status,
                        updated_at = excluded.updated_at
                    """,
                    (
                        username,
                        full_name,
                        role,
                        "R692",
                        "R692",
                        "Apple 가로수길",
                        "srs_korea",
                        app.USER_STATUS_ACTIVE,
                        "hash",
                        self.timestamp,
                        self.timestamp,
                    ),
                )
            conn.commit()
            reporter_row = conn.execute(
                "SELECT id FROM users WHERE username = ?",
                ("detail_reporter",),
            ).fetchone()
            self.reporter_user_id = int(reporter_row["id"] if reporter_row else 0)
            hq_row = conn.execute(
                "SELECT id FROM users WHERE username = ?",
                ("detail_hq_admin",),
            ).fetchone()
            self.hq_user_id = int(hq_row["id"] if hq_row else 0)
        finally:
            conn.close()

    def _build_hq_user(self):
        return {
            "id": self.hq_user_id,
            "username": "detail_hq_admin",
            "full_name": "상세 본사",
            "role": "hq_admin",
            "location": "R692",
            "site_id": "R692",
            "site_name": "Apple 가로수길",
            "tenant_id": "srs_korea",
            "status": app.USER_STATUS_ACTIVE,
        }

    def _build_handler(self, user):
        sent = []
        handler = object.__new__(app.SecurityOpsHandler)
        handler.require_user = MethodType(lambda _self: dict(user), handler)
        handler.send_json = MethodType(lambda _self, status, payload: sent.append((status, payload)), handler)
        handler.send_api_error = MethodType(lambda _self, status, message: sent.append((status, {"error": message})), handler)
        handler._get_user_tenant_id = MethodType(lambda _self, current_user: str((current_user or {}).get("tenant_id") or "srs_korea"), handler)
        return handler, sent

    def _insert_ticket(self, *, display_no, template_type, title, payload, status="pending", description="desc"):
        conn = app.db_connect()
        try:
            cursor = conn.execute(
                """
                INSERT INTO tickets (
                    display_no, template_type, title, description, location, site_id, tenant_id,
                    status, reporter_user_id, created_at, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    display_no,
                    template_type,
                    title,
                    description,
                    "R692",
                    "R692",
                    "srs_korea",
                    status,
                    self.reporter_user_id,
                    self.timestamp,
                    self.timestamp,
                ),
            )
            ticket_id = int(cursor.lastrowid or 0)
            conn.execute(
                """
                INSERT INTO tickets_template_fields (ticket_id, template_type, payload_json, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?)
                """,
                (
                    ticket_id,
                    template_type,
                    json.dumps(payload or {}, ensure_ascii=False),
                    self.timestamp,
                    self.timestamp,
                ),
            )
            conn.commit()
            return ticket_id
        finally:
            conn.close()

    def _consume_hq_upload_support_ticket(self):
        month_key = "2026-03"
        month_start = date.fromisoformat(f"{month_key}-01")
        next_month_start = date(month_start.year, month_start.month + 1, 1)
        with patch.object(app, "_emit_support_roster_update_side_effects", return_value={}), patch.object(
            app,
            "_emit_support_roster_batch_notification",
            return_value=True,
        ):
            result = app._consume_support_roster_scope_snapshots(
                tenant_id="srs_korea",
                batch_id="detail-hq-batch-1",
                scope_snapshots=[
                    {
                        "scope_key": "R692:2026-03-16:day",
                        "site_code": "R692",
                        "work_date": "2026-03-16",
                        "shift_kind": "day",
                        "request_count": 1,
                        "purpose_text": "ARLS HQ 업로드 지원",
                        "workers": [
                            {
                                "affiliation": "자체",
                                "worker_name": "업로드 지원자",
                                "raw_display": "자체 업로드 지원자",
                                "self_staff": True,
                            }
                        ],
                    }
                ],
                replace_scope={
                    "mode": "site_month_full_snapshot",
                    "snapshot_mode": "replace",
                    "month": month_key,
                    "site_codes": ["R692"],
                    "shift_kinds": ["day", "night"],
                    "date_scope": {
                        "kind": "calendar_month",
                        "start_date": month_start.isoformat(),
                        "end_date": (next_month_start - timedelta(days=1)).isoformat(),
                    },
                },
                artifact_id="detail-artifact-1",
                revision="detail-revision-1",
                month=month_key,
                source_upload_batch_id="detail-upload-1",
                source_kind="arls_support_snapshot_consumer",
            )
        self.assertTrue(result["applied"])
        conn = app.db_connect()
        try:
            row = conn.execute(
                """
                SELECT t.id
                FROM tickets t
                JOIN tickets_template_fields tf ON tf.ticket_id = t.id
                WHERE t.tenant_id = ?
                  AND t.template_type = ?
                  AND COALESCE(tf.payload_json, '') LIKE ?
                ORDER BY t.id DESC
                LIMIT 1
                """,
                ("srs_korea", "주간 지원 요청", "%detail-upload-1%"),
            ).fetchone()
            return int(row["id"] if row else 0)
        finally:
            conn.close()

    def _patch_support_side_effect_dependencies(self):
        return patch.multiple(
            app,
            BROKER=_BrokerStub(),
            list_hq_admin_usernames=lambda conn, tenant_id="": [],
            list_site_supervisor_usernames=lambda conn, site_id="", tenant_id="": [],
            send_apns_to_users=lambda *args, **kwargs: {"requested": 0, "sent": 0, "failed": 0},
            send_apns_to_users_async=lambda *args, **kwargs: True,
            enqueue_hr_approval_outbox_event=lambda **kwargs: True,
        )

    def test_hidden_hq_upload_ticket_stays_out_of_list_but_support_detail_lookup_works(self):
        ticket_id = self._consume_hq_upload_support_ticket()
        self.assertGreater(ticket_id, 0)
        handler, sent = self._build_handler(self._build_hq_user())

        handler.handle_list_tickets()
        self.assertEqual(sent[-1][0], 200)
        visible_ticket_ids = [int(ticket["id"]) for ticket in sent[-1][1]["tickets"]]
        self.assertNotIn(ticket_id, visible_ticket_ids)

        handler.handle_get_ticket_detail(f"/api/tickets/{ticket_id}")
        self.assertEqual(sent[-1][0], 200)
        detail_payload = sent[-1][1]["ticket"]
        self.assertEqual(int(detail_payload["id"]), ticket_id)
        self.assertTrue(detail_payload["support_origin_hq_upload"])
        self.assertIn(
            "support_request_created",
            [str(event.get("event_type") or "") for event in detail_payload.get("support_timeline_events") or []],
        )

        handler.handle_get_ops_support_requests(urlparse("/api/ops/support-requests?from=2026-03-01&to=2026-03-31"))
        self.assertEqual(sent[-1][0], 200)
        support_items = sent[-1][1]["items"]
        matched = next(
            item for item in support_items
            if int(item["ticket_id"]) == ticket_id
        )
        self.assertTrue(isinstance(matched.get("comments"), list))
        self.assertTrue(isinstance(matched.get("status_history"), list))
        self.assertIn(
            "support_request_created",
            [str(event.get("event_type") or "") for event in matched.get("support_timeline_events") or []],
        )

    def test_support_worker_add_update_remove_events_are_available_to_support_request_history(self):
        ticket_id = self._insert_ticket(
            display_no=9101,
            template_type="주간 지원 요청",
            title="지원 요청",
            payload={
                "request_date": "2026-03-16",
                "requested_count": 1,
                "workPurpose": "지원 요청",
                "support_request_status": "pending",
            },
        )
        handler, sent = self._build_handler(self._build_hq_user())

        def _submit_workers(workers):
            with patch.object(app, "parse_json_body", return_value={"confirmed_workers": workers}), self._patch_support_side_effect_dependencies():
                handler.handle_patch_ops_support_confirmed_workers(f"/api/ops/support-requests/{ticket_id}/confirmed-workers")
            self.assertEqual(sent[-1][0], 200)

        _submit_workers([{"affiliation": "자체", "worker_name": "홍길동"}])
        _submit_workers([{"affiliation": "자체", "worker_name": "김철수"}])
        _submit_workers([])

        handler.handle_get_ops_support_requests(urlparse("/api/ops/support-requests?from=2026-03-01&to=2026-03-31"))
        self.assertEqual(sent[-1][0], 200)
        support_items = sent[-1][1]["items"]
        matched = next(
            item for item in support_items
            if int(item["ticket_id"]) == ticket_id
        )
        event_types = [str(event.get("event_type") or "") for event in matched.get("support_timeline_events") or []]
        self.assertIn("support_worker_added", event_types)
        self.assertIn("support_worker_updated", event_types)
        self.assertIn("support_worker_removed", event_types)


if __name__ == "__main__":
    unittest.main()
